package com.revature.annotations;

public enum AuthRestriction {
    LoggedIn
}
